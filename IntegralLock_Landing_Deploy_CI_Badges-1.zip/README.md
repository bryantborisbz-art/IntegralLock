# IntegralLock Landing Page

Integration-themed lockscreen challenge landing page 🚀  
Auto-deploys to **Netlify** and **Vercel** on every push to `main`.

---

## 🚦 Build & Deployment Status

[![Netlify Deploy](https://img.shields.io/netlify/YOUR_SITE_ID?logo=netlify)](https://app.netlify.com/sites/YOUR_SITE_NAME/deploys)  
[![Vercel Deploy](https://therealsujitk-vercel-badge.vercel.app/?app=YOUR_PROJECT_NAME)](https://vercel.com/YOUR_ORG/YOUR_PROJECT_NAME)

---

## 🔑 GitHub Secrets Required

- `NETLIFY_AUTH_TOKEN` → Netlify Access Token  
- `NETLIFY_SITE_ID` → Netlify Site ID  
- `VERCEL_TOKEN` → Vercel Token  
- `VERCEL_ORG_ID` → Vercel Org ID  
- `VERCEL_PROJECT_ID` → Vercel Project ID  

---

## ⚡ Deploy Flow
- Push to `main` → GitHub Actions builds and deploys →  
   ✅ Netlify  
   ✅ Vercel  

Check deployment logs in [GitHub Actions](https://github.com/YOUR_USERNAME/YOUR_REPO/actions).
